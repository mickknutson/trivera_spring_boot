package com.springclass.boot.service;

public class UserService {

}
